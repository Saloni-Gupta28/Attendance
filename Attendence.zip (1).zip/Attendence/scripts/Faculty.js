import { User } from "./User.js";

export class Faculty extends User{
    constructor(name,pass)
    {
        super(name,pass);
        this.role="Faculty";
    }
}