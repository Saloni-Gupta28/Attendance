
export class User{
    constructor(name,pass)
    {
        this.id="User--"+ new Date().getTime();
        this.name=name;
        this.pass=pass;
    }
}