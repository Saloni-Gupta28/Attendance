import { User } from "./User.js";

export class Student extends User{
    constructor(name,pass)
    {
        super(name,pass);
        this.role="Student";
    }
}