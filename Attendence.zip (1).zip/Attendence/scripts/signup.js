import { Faculty } from "./Faculty.js";
import { Student } from "./Student.js";


let users=[]
document.addEventListener("DOMContentLoaded",() =>{

    let LoginButton=document.getElementById("loginbutton");
    LoginButton.addEventListener('click',registeruser);

})


const registeruser = (e) => {
    e.preventDefault();
    let Username = document.getElementById("UserName").value;
    let Userpass = document.getElementById("UserPassword").value;
    let Userrole = document.getElementById("typeSelect").value;
    
  let user=null;     
  switch(Userrole)
  { 
     case "Student":
     user=new Student(Username,Userpass)
     break;

     case "Faculty":
     user=new Faculty(Username,Userpass)
     break;

  }
  users.push(user)
  console.log(users)
}
document.addEventListener("DOMContentLoaded",()=>{
    const usernameInput = document.getElementById('UserName');
    const passwordInput = document.getElementById('UserPassword');
    const selectInput = document.getElementById('typeSelect');
    const buttonInput = document.getElementById('loginbutton');
    
    const checkFields = () => {
        const UserName = usernameInput.value;
        const UserPassword = passwordInput.value;
        const selectedType = selectInput.value;
    
        buttonInput.disabled = !(UserName && UserPassword && selectedType);
    };
    
    usernameInput.addEventListener('input', checkFields);
    passwordInput.addEventListener('input', checkFields);
    selectInput.addEventListener('change', checkFields);
    
    
    buttonInput.addEventListener('click',()=>{
        window.location.replace("./login.html");
    })
    
})

